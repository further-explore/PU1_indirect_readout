%pdb_array= { 'Abeta42_1' 'Abeta40_1'};
pdb_array= { 'round1' 'Abeta40_2' 'Abeta40_3' 'Abeta40_6_nonfibril'};
sim_labels = [14 7 6 4];

qa_name ='Bindc_total';%new rxn co
T=300;
binN=50;
color={'b','r','g','b','m'};
dih_range=16:22;

curve_shift_flag=1; q0_shift=-32;
%; qmono_flag =0;

%if qmono_flag == 1
%    path = sprintf('~/work/mdbox/qbias_mono/%s', pdbID_upper);
%else
%    path = sprintf('~/work/mdbox/qbias/%s',      pdbID_upper);
%endround1_
cutoff=30;
scrnsize = get(0,'ScreenSize'); 
%figure('position', [1 scrnsize(4) 0.3*scrnsize(3) 0.4*scrnsize(4)]), hold on
fsize=25; tsize=16; %mr=3; mc=2;
%for i_list = 1:length(T_list)
    %T = T_list(i_list);
    %subplot(mr, mc, i_list),
    %grid on, hold on, set(gca, 'fontsize', tsize); xlabel('Q', 'fontsize', fsize); ylabel('F (kcal/mol)', 'fontsize', fsize); 
    for i_label=1:3
        sim_label = sim_labels(1);
        pdbID_upper = pdb_array{1};
        path = sprintf('/home/xun/victor/design/%s',pdbID_upper)
        %title([pdbID_upper, ' ', num2str(T), 'K'], 'fontsize', fsize);
        
        filename = sprintf('%s/%s',path, qa_name); qa = load(filename);        
        if strcmp(qa_name,'dih')
            qa=(mean(qa(:,dih_range)'))';
        end
        
        %load q
        filename = sprintf('%s/p_total',path); q = load(filename);
        %if qo_flag == 1
        %    filename = sprintf('%s/qo_%d',path, sim_label); qo = load(filename); 
        %end
        Nsample = length(q);    

        %load pmf file and calculate pi_sample
        filename=sprintf('%s/%s_%d_pmff%d.dat',path, pdbID_upper,T,i_label);        

        FF=load(filename); qx=FF(:,1);  Fy = FF(:,2); nbin=length(qx);
        dq=qx(2)-qx(1); qmin=qx(1)-dq/2; qmax= qx(nbin)+dq/2;
        Py=exp(-Fy/(0.001987*T)); P_norm = sum(Py); Py=Py/P_norm;
        pi_sample = zeros(Nsample,1); ni_sample = zeros(nbin, 1);
        %calculate pi_sample
        for i_bin= 1:nbin
            qi_min = qmin + (i_bin-1)*dq; qi_max= qi_min + dq;
            ids = find( q >= qi_min & q < qi_max ) ;    
            ni_sample(i_bin) = length(ids);        
            if ni_sample(i_bin) > 0
                pi_sample(ids) = Py(i_bin)/ni_sample(i_bin);
            end
        end    
        fprintf('probability = %.3f\n', sum(pi_sample));                        

        qa_lin=linspace(min(qa), max(qa),binN);
        count_qa=zeros(binN,1);
        [~,bin_index_x]=histc(qa, qa_lin);
        for i_sample=1:Nsample
            x=bin_index_x(i_sample);
            count_qa(x) = count_qa(x) + pi_sample(i_sample);
        end
        fprintf('Total probability for new coordinate is %.3f\n',sum(count_qa));
        F_qa=-0.001987*T*log(count_qa); ids = (F_qa>= cutoff); F_qa(ids) = cutoff;
        F_qa=smooth(F_qa)
        if curve_shift_flag==0
            Fmin = min(F_qa); id_shift = find( F_qa == Fmin );
        else
            [~,id_shift]=min(abs(qa_lin-q0_shift));
        end

        
     %dlmwrite([path,'/bindqa','.txt'],qa_lin)
     %   dlmwrite([path,'/bindF','.txt'], F_qa-F_qa(id_shift(1)))
        %plot F Vs. Qo, shift free energy curve    
        %Fmin = min(FF(:,2)); id_shift = find( FF(:,2) == Fmin );    
        %xlim([0 1]);
        %id_shift(1)=35;
        %plot(FF(:,1), FF(:,2)-FF(id_shift(1),2), 'linewidth', 3); 
        %if i_list == 1
        %    legend('T400','T420','T440','T450','fontsize',fsize);
        %end
        plot(qa_lin, F_qa-F_qa(50), color{i_label}, 'linewidth', 3);hold on; 
        %dlmwrite([path,'/qalin.txt'],qa_lin)
        dlmwrite([path,'/Fqa',num2str(i_label),'.txt'],F_qa)
        fsize=40; tsize=16;
        xlim([1 100])
        xlabel('Base pair index', 'fontsize', fsize); ylabel('Free energy (kcal/mol)', 'fontsize', fsize); title('Free energy', 'fontsize', fsize);
        set(gca,'fontsize',fsize/2)
        saveas(gcf,[path,'/bind.png'])
    end
    legend('0.01M','0.1M','1M')