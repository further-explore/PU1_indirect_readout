path = '/home/xc25/Data_dealing/PU_1/update6/Takada_redo/setup2/'
q_name = {'angle','charge'};xname = 'local bending angle';yname = 'charge density surface'
T=300
binN=30;ObinN=30;
prefix='setup2'
n_contour=20; % # of contour lines
fsize=40; tsize=20; mr=1; mc=1;
cutoff=10;scrnsize = get(0,'ScreenSize'); 
figure('position', [1 scrnsize(4) 0.25*mc*scrnsize(3) 0.35*scrnsize(4)]);
qa_name=q_name{1}; qb_name=q_name{2};
filename = sprintf('%s/%s',path, qa_name); qa = 180 - load(filename);
filename = sprintf('%s/%s',path, qb_name); qb = load(filename);
if strcmp(q_name{1},'dih')
   qa=(mean(qa'))';
end
if strcmp(q_name{2},'dih')
   qb=(mean(qb'))';
end
qa_min=min(qa); qa_max=max(qa);
qb_min=min(qb); qb_max=max(qb);

Nsample=size(qa,1);
%assert(Nsample==size(qb,1));
filename = sprintf('%s/p_total',path); q = load(filename);
filename=sprintf('%s/%s_%d_pmf.dat',path,prefix, T);
FF=load(filename); qx=FF(:,1);  Fy = FF(:,2); nbin=length(qx);
dq=qx(2)-qx(1); qmin=qx(1)-dq/2; qmax= qx(nbin)+dq/2;
Py=exp(-Fy/(0.001987*T)); P_norm = sum(Py); Py=Py/P_norm;
pi_sample = zeros(Nsample,1); ni_sample = zeros(nbin, 1);
for i_bin= 1:nbin
        qi_min = qmin + (i_bin-1)*dq; qi_max= qi_min + dq;
        ids = find( q >= qi_min & q < qi_max ) ;    
        ni_sample(i_bin) = length(ids);        
        if ni_sample(i_bin) > 0
            pi_sample(ids) = Py(i_bin)/ni_sample(i_bin);
        end
end
fprintf('probability = %.3f\n', sum(pi_sample));
qa_max=100,qa_min=0
qb_max=4.5,qb_min=0
qa_lin=linspace(qa_min,qa_max,ObinN); qb_lin=linspace(qb_min, qb_max,binN); H=zeros(ObinN,binN);
[~, bin_index_x] = histc(qa, qa_lin); [~, bin_index_y] = histc(qb, qb_lin);
for i_sample = 1:Nsample
        x=bin_index_x(i_sample); y=bin_index_y(i_sample);
        if x > 0 & x < (ObinN + 1) & y > 0 & y< (binN +1)
           H(x,y) = H(x,y) + pi_sample(i_sample);
        end
end
H=H'; fprintf('sum(sum(H))=%.3f\n', sum(sum(H)));     
F_wham=-0.001987*T*log(H);ids = (F_wham>= cutoff); F_wham(ids) = inf; 
%subplot(mr,mc,i_label)
q_name = {'angleo','chargeo'};xname = 'local bending angle';yname = 'charge density surface'
qa_name=q_name{1}; qb_name=q_name{2};
filename = sprintf('%s/%s',path, qa_name); qa = load(filename);
filename = sprintf('%s/%s',path, qb_name); qb = load(filename)%/3.14159*180 ;
if strcmp(q_name{1},'dih')
        qa=(mean(qa'))';
end
if strcmp(q_name{2},'dih')
        qb=(mean(qb'))';
end
 Nsample=size(qa,1);
 nbin=length(qa)
 pi_sample = zeros(Nsample,1); ni_sample = zeros(nbin, 1);
 qa_lin=linspace(qa_min,qa_max,ObinN); 
 qb_lin=linspace(qb_min,qb_max,binN); 
 H=zeros(ObinN,binN);
 [~, bin_index_x] = histc(qa, qa_lin); [~, bin_index_y] = histc(qb, qb_lin);
 delta = 1.0/nbin
 for i_sample = 1:Nsample
        x=bin_index_x(i_sample); y=bin_index_y(i_sample);
        if x > 0 & x < (ObinN + 1) & y > 0 & y< (binN +1)
           H(x,y) = H(x,y) + delta;
        end
 end
 H=H'; fprintf('sum(sum(H))=%.3f\n', sum(sum(H)));     
 F_nowham=-0.001987*T*log(H);
 ids = (F_nowham>=cutoff); F_nowham(ids) >= cutoff;F(id) = inf
 F = F_wham - F_nowham
 subplot(mr,mc,i_label)
 [~,h] = contourf(qa_lin, qb_lin,F,n_contour,'edgecolor','none'); shading flat
    %[xnew,ynew]=meshgrid(linspace(min(qa),max(qa),newpoints1),linspace(min(qb),max(qb),newpoints2))
    %[xnew,ynew]=meshgrid(linspace(-8,4,newpoints),linspace(-4,4,newpoints))
    %ids = (F>= cutoff-2); F(ids) = cutoff+30;
    %znew=interp2(qa_lin,qb_lin,F,xnew,ynew,'spline')
    %ids = (znew>=cutoff-1);znew(ids) = cutoff
    %[~,h] = contourf(xnew,ynew,znew,n_contour,'edgecolor','none'); shading flat
    
    colormap(jet), col=colorbar, %set(col,'ylim',[0 10])name
    cm=colormap
    %cm(64, :) = [1 1 1];
ccc = get(h,'children'); max_cdata = -inf; cdata_list=zeros(size(ccc,1), 1);
    
for k=1:size(ccc,1)
        cd1 = get(ccc(k), 'cdata');
        if cd1 > max_cdata
            max_cdata = cd1 ;
        end
        cdata_list(k) = get(ccc(k),'cdata');
end
id = find(cdata_list == max_cdata);
disp(ccc(id));
for k=1:size(id,1)
        set(ccc(id(k)), 'facecolor', 'white');
end

set(gca,'fontsize',fsize/2)
xlabel(xname, 'fontsize', fsize/2)
ylabel(yname, 'fontsize', fsize/3)
%xlim([qa_min,qa_max])
xlim([0,100])
ylim([1.5,5])
%title(titlename,'fontsize',fsize/4)
saveas(gcf,[path,'/',prefix,'-',xname,'-',yname,'.png'])
%caxis([0,8])