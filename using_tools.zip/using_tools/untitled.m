 cm=colormap(jet(16))
curve_shift_flag=1; q0_shift=0.55;
cutoff=10;
scrnsize = get(0,'ScreenSize'); 
fsize=25; tsize=16;
index = 1
prefix = 'round5' 
path = '/home/xun/victor/temp3/'
filename = sprintf('%s/qalin.txt',path); qa = load(filename);
filename = sprintf('%s/Fqa.txt',path); Fqa = load(filename);
Fqa=smooth(Fqa)
   Fmin = min(Fqa); id_shift = find( Fqa == Fmin );
plot(qa, Fqa-Fqa(id_shift(1)),'color', cm(index+4,:), 'linewidth', 4);   hold on;
fsize=30; tsize=16;
xlabel('base pair index', 'fontsize', fsize); ylabel('Free energy (kcal/mol)', 'fontsize', fsize); %title([titlename], 'fontsize', fsize);set(gca,'fontsize',fsize)
set(gca,'fontsize',fsize/2)
xlim([1 100])