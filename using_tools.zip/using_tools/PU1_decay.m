filename = '/home/xun/victor/dist/decay/Twist_bound_r'
FF=load(filename); s=(FF(:,1)); ll =log(FF(:,2)); 