path = sprintf('/home/xc25/Simulation_prepare/mc70_dirty_work/forsky/T0877')
qa_name = 'x'
filename = sprintf('%s/%s',path, qa_name);
FF=load(filename); qa=FF(:,1);  Fy = FF(:,1);
nbin = 50
dq=(max(qa)-min(qa))/nbin; qmin=min(qa)-dq/2; qmax= max(qa)+dq/2;
%dq=(4-min(qa))/nbin;qmax=4;
Nsample = length(qa);
qa_lin=linspace(min(qa),max(qa),nbin);H=zeros(nbin);
[~, bin_index_x] = histc(qa, qa_lin);
for i_sample = 1:Nsample
        x=bin_index_x(i_sample);
        H(x) = H(x) + 1.0/Nsample;
end
bar(qa_lin,H,'stacked')
ylabel("probaility")
xlabel("rmsd")
title("T0877")