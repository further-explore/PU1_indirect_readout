path = '/home/xun/victor/pers/test/'
name = 'off'
filename = sprintf('%s/Bending-%s_Re.txt',path,name); x = load(filename);
%x=3:2:99
filename = sprintf('%s/Bending-%s_u0us.txt',path,name); F = load(filename);
scatter(x, F,20,'filled'), hold on;