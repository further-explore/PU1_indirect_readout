import os
import sys
import numpy as np
file1=sys.argv[1]
file2=sys.argv[2]
data1=np.loadtxt(file1)
data2=np.zeros(len(data1)/2)
for i in range(len(data2)):
    data2[i] =  (data1[i*2]+data1[i*2+1])/2
np.savetxt(file2,data2,fmt="%.3f",delimiter="\n")
