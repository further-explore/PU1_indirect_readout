import os
import sys
import numpy as np
file1=sys.argv[1]
file2=sys.argv[2]
file3=sys.argv[3]
data1=np.loadtxt(file1)
data2=np.loadtxt(file2)
data3=np.zeros(len(data1))
for i in range(len(data2)):
    data3[i] =  (data1[i]/1.53/1.01-data2[i])
np.savetxt(file3,data3,fmt="%.3f",delimiter="\n")
