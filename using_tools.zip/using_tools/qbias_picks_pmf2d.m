%Plot 2d pmf
%Option: select structure within a range and Write snapshots into a file
%
pdb_array= {'PU 1'};
sim_labels = [2];
repeats = [20];

% order parameters for the 2d-plot
%q_name={'Intra-Anti-Para', 'Inter-Para'};

%q_name={'ELEC_total', 'ANGLOCAL_bp13_total'};
%q_name={'ELEC_total', 'DANGLE_total'};
%q_name={'ELEC_total', 'DAB-CD_total'};
%q_name={'ELEC_total', 'pca_pc5_total'};
%q_name={'ELEC_total', 'pca2_pc2_total'};
%q_name={'ELEC_total', 'NCOUNTS_NtoN_total'}
%q_name={'pca2_pc1_total', 'pca2_pc4_total'};
%q_name={'NCOUNTS_NtoN_total', 'DAB-CD_total'};
%q_name={'ELECABCD_total', 'ELEC_total'};

%q_name={'ELEC_total', 'pca2_pc6_total'};
%q_name={'ELEC_total', 'pca2_weighted_pc3_total'};
%q_name={'pca2_pc1_total', 'pca2_pc4_total'};
%q_name={'pca2_weighted_pc1_total', 'pca2_weighted_pc4_total'};
%q_name={'pca2_weighted_pc2_total', 'pca2_weighted_pc3_total'};

%q_name={'ELEC_total', 'QBINFIS_total'};
%q_name={'ELEC_total', 'pca3_7Vars_weighted_pc1_total'};
q_name={'pca3_7Vars_weighted_pc1_total', 'pca3_7Vars_weighted_pc3_total'};
q_name = {'angle.dat_total-picks','charge_dna_surface_total-picks'};xname = 'local bending angle';yname = 'charge density surface'
q_name = {'angle.dat_total-picks','dist_protein_dna_bindsite_min_total-picks'};xname = 'local bending angle';yname = 'distmin'
q_name = {'charge_dna_surface_total-picks','dist_protein_dna_bindsite_min_total-picks'};xname = 'charge density surface';yname = 'distmin'
q_name={  'largest_oligomer_total' ,'tc_total'};xname = 'largest oligomer size',yname='contact number'
q_name = {'angleo','chargeo'};xname = 'local bending angle';yname = 'charge density surface'
write_snapshot_flag=0; 

%qa_x_dx=[10.86 0.5]; qb_y_dy=[6.90 0.5]; %anti-para-basin
%qa_x_dx=[6.4 0.5]; qb_y_dy=[24.6 0.5];  %Intermediate29247
%qa_x_dx=[8.55 0.5]; qb_y_dy=[15.34 0.5]; %TS-anti-inter
%qa_x_dx=[0.55 0.005]; qb_y_dy=[22.5 0.3]; %TS-anti-inter
qa_x_dx=[75 5]; qb_y_dy=[3 0.5]; %

% Q-bias reaction coordinate
qbias_name='p_total';
T=300;

n_contour=20; % # of contour lines
fsize=20; tsize=15; mr=1; mc=length(sim_labels);
cutoff=25;scrnsize = get(0,'ScreenSize'); 
figure('position', [1 scrnsize(4) 0.5*mc*scrnsize(3) 0.7*scrnsize(4)]);

for i_label=1:length(sim_labels)
    protein_i = i_label; pdbID_upper = pdb_array{protein_i};
    path = sprintf('~/work/awsemmd_proteinDNA/%s/wham/run008-012.1-48', pdbID_upper);
    path = '/home/xc25/Data_dealing/PU_1/update6/design/setup2/'
   
    %path = sprintf('/home/xc25/Data_dealing/tau_R134/tau')
    sim_label = sim_labels(i_label); repeat=repeats(i_label);
    qa_name=q_name{1}; qb_name=q_name{2};
    out_file=sprintf('%s/snapshot_select.dat', path);    
    %load data
    filename = sprintf('%s/%s',path, qa_name); qa = load(filename);
    filename = sprintf('%s/%s',path, qb_name); qb = load(filename);

    %special treatment for 'dih' order parameter
    if strcmp(qa_name,'dih') 
        qa=(mean(qa'))';
    end
    if strcmp(qb_name,'dih')[~,h] = contourf(qa_lin, qb_lin,F,n_contour); %shading flat,
    title([num2str(pdbID_upper), ' T= ', num2str(T)],'fontsize', fsize);
        qb=(mean(qb'))';
    end
    if strcmp(qa_name, 'count_beta_bonds')
            qa=qa(:,1);%-qa(:,3)-qa(:,1);
    end
    if strcmp(qb_name, 'count_beta_bonds')
            qb=qb(:,4); %-qb(:,3)-qb(:,1);
    end
    if strcmp(qa_name, 'energy')
            qa=qa(:,size(qa,2));
    end
    if strcmp(qb_name, 'energy')
            qb=qb(:,size(qb,2));
    end

    if i_label==1
        qa_min=min(qa); qa_max=max(qa);
        qb_min=min(qb); qb_max=max(qb);
    end

    Nsample=size(qa,1); assert(Nsample==size(qb,1));
    Nline = Nsample/repeat;
    %load pmf file and calculate the unbiased probability for each sample(pi_sample)
    T_i=T; T=T_i;
    filename = sprintf('%s/%s',path, qbias_name); q = load(filename);
    %filename=sprintf('%s/pmf/fis2DNA_%d_pmf.dat',path, T_i);
    filename=sprintf('%s/setup2_%d_pmf.dat',path, T_i);
    FF=load(filename); qx=FF(:,1);  Fy = FF(:,2); nbin=length(qx);
    dq=qx(2)-qx(1); qmin=qx(1)-dq/2; qmax= qx(nbin)+dq/2;
    Py=exp(-Fy/(0.001987*T_i)); P_norm = sum(Py); Py=Py/P_norm;
    pi_sample = zeros(Nsample,1); ni_sample = zeros(nbin, 1);
    %calculate pi_sample
    for i_bin= 1:nbin
        qi_min = qmin + (i_bin-1)*dq; qi_max= qi_min + dq;
        ids = find( q >= qi_min & q < qi_max ) ;    
        ni_sample(i_bin) = length(ids);        
        if ni_sample(i_bin) > 0
            pi_sample(ids) = Py(i_bin)/ni_sample(i_bin);
        end
    end    
    fprintf('probability = %.3f\n', sum(pi_sample));
    
    %Use pi_sample to construct 2d probability matrix H(x,y)
    binN=30;
    qa_lin=linspace(min(qa), max(qa),binN); qb_lin=linspace(min(qb), max(qb),binN); H=zeros(binN,binN);
    [~, bin_index_x] = histc(qa, qa_lin); [~, bin_index_y] = histc(qb, qb_lin);
    for i_sample = 1:Nsample
        x=bin_index_x(i_sample); y=bin_index_y(i_sample);
        H(x,y) = H(x,y) + pi_sample(i_sample);
    end
    H=H'; fprintf('sum(sum(H))=%.3f\n', sum(sum(H)));
    F=-0.001987*T*log(H); ids = (F>= cutoff); F(ids) = cutoff; 

    %plot 2d-pmf
    subplot(mr,mc,i_label)
    [~,h] = contourf(qa_lin, qb_lin,F,n_contour); %shading flat,
    title([num2str(pdbID_upper), ' T= ', num2str(T)],'fontsize', fsize);
    %%%fill the top area white
    ccc = get(h,'Children'); max_cdata = -inf; cdata_list=zeros(size(ccc,1), 1);
    for k=1:size(ccc,1)
        cd1 = get(ccc(k), 'cdata');
        if cd1 > max_cdata
            max_cdata = cd1 ;
        end
        cdata_list(k) = get(ccc(k),'cdata');
    end
    id = find(cdata_list == max_cdata);
    for k=1:size(id,1)
        set(ccc(id(k)), 'facecolor', 'white');
    end
    set(h,'linestyle','none');
    colormap(jet), colorbar, 
    xlabel(q_name{1}, 'fontsize', fsize), 
    ylabel(q_name{2}, 'fontsize', fsize); 
    xlabel(xname, 'fontsize', fsize), 
    ylabel(yname, 'fontsize', fsize); 
    set(gca, 'FontSize', fsize);
    xlim([qa_min, qa_max])
    ylim([qb_min, qb_max])
    
    if write_snapshot_flag == 1
        prompt = 'Do you want to write the snapshot indices to a file? y/n [Press Enter for y]';
        str=input(prompt,'s');        
        nrow=1:Nsample;
        if strcmp(str,'Y') || strcmp(str,'y') || isempty(str)
            str2 = 'y';
            dx=qa_x_dx(2); dy=qb_y_dy(2);            
            while(strcmp(str2,'y') || strcmp(str2,'Y'))
                qa_min = qa_x_dx(1) - dx; qa_max = qa_x_dx(1) + dx;
                qb_min = qb_y_dy(1) - dy; qb_max = qb_y_dy(1) + dy;
                nrow_a = find( qa>qa_min & qa<qa_max);
                nrow_b = find( qb>qb_min & qb<qb_max);
                fprintf('qa_min:%d, qa_max:%d\n', qa_min, qa_max);
                fprintf('qb_min:%d, qb_max:%d\n', qb_min, qb_max);
                nrow = intersect(nrow_a, nrow_b);
                fprintf('Number of snapshots is qa:%d qb:%d both:%d.\n', length(nrow_a), length(nrow_b), length(nrow));
                prompt3='Do you wish to change dx/dy for qa/qb? [y/n] (Press Enter for y)';
                str3=input(prompt3, 's');
                if strcmp(str3,'y') || strcmp(str3,'Y') || isempty(str3)
                    prompt='How do you want to change dx? Input the scaling factor (a*dx) a= ';
                    a=input(prompt); dx=a*dx;
                    prompt='How do you want to change dy? Input the scaling factor (b*dy) b= ';
                    b=input(prompt); dy=b*dy;
                else
                    str2='n';
                end                
            end            
        end
        out=fopen(out_file,'w');qb_y_dy
        for i_nrow = 1:length(nrow)
            if i_nrow>1 && floor((nrow(i_nrow)-1)/Nline)-floor((nrow(i_nrow-1)-1)/Nline) >= 1
                fprintf(out,'\n');
            end
            fprintf(out, '%d ', nrow(i_nrow));
        end
        fprintf(out,'\n');
        fclose(out);
    end
end
%xlim([0,100])
%ylim([0,5])
saveas(gcf,[path,'/',xname,yname,'.png'])
