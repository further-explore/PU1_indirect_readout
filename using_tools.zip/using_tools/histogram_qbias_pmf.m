disp(T)
qa_name ='Bindc_total';%new rxn co
filp_name = 'Flip_total'
binN=16;
color={'r','m','g','b'};
dih_range=16:22;
n_T=16;
cv=zeros(n_T,1); cm=colormap(jet(n_T))
curve_shift_flag=1; q0_shift=0.55;
cutoff=20;
scrnsize = get(0,'ScreenSize'); 
fsize=20; tsize=16;
index = 1
prefix = 'angle_P' 
qa_name_label = 'Binding site'
xname='Binding site'
yname='Probability'
titlename='Distribution of Binding site of Flip'
%for i_label=1
%sim_label = sim_labels(i_label);
%pdbID_upper = pdb_array{i_label};
path = sprintf('/home/xc25/Data_dealing/51bp_right');
path = sprintf('/home/xc25/Data_dealing/PU_1_variable/angle_bias/angle_P');
%path = '/home/xc25/Data_dealing/PU_1_variable/window_1_6/dist_P'
filename = sprintf('%s/%s',path, qa_name); qa = load(filename);
filename = sprintf('%s/Flip_total',path); flip = load(filename);
if strcmp(qa_name,'dih')
   qa=(mean(qa(:,dih_range)'))';
end
filename = sprintf('%s/p_total',path); q = load(filename);
Nsample = length(q);
filename=sprintf('%s/%s_%d_pmf.dat',path,prefix,T); 
FF=load(filename); qx=FF(:,1);  Fy = FF(:,2); nbin=length(qx);
dq=qx(2)-qx(1); qmin=qx(1)-dq/2; qmax= qx(nbin)+dq/2;
Py=exp(-Fy/(0.001987*T)); P_norm = sum(Py); Py=Py/P_norm;
pi_sample = zeros(Nsample,1); ni_sample = zeros(nbin, 1);


for i_bin= 1:nbin
    qi_min = qmin + (i_bin-1)*dq; qi_max= qi_min + dq;
    ids = find( q >= qi_min & q < qi_max ) ;    
    ni_sample(i_bin) = length(ids);        
    if ni_sample(i_bin) > 0
       pi_sample(ids) = Py(i_bin)/ni_sample(i_bin);
    end
end

fprintf('probability = %.3f\n', sum(pi_sample));
qa_lin=linspace(min(qa), max(qa),binN);
count_qa=zeros(binN,1);
count_flip=zeros(binN,1);
[~,bin_index_x]=histc(qa, qa_lin);

for i_sample=1:Nsample
    x=bin_index_x(i_sample);
    count_qa(x) = count_qa(x) + pi_sample(i_sample);
    if flip(i_sample) == -1
       count_flip(x) = count_flip(x) + pi_sample(i_sample);
    end
end
for i=1:binN
    if count_qa(i) > 0
       count_qa(i) = count_flip(i)/count_qa(i);
    end
end
fprintf('Total probability for new coordinate is %.3f\n',sum(count_qa));
%F_qa=-0.001987*T*log(count_qa); ids = (F_qa>= cutoff); F_qa(ids) = cutoff;
bar(qa_lin,count_qa)
%if curve_shift_flag==0
 %  Fmin = min(F_qa); id_shift = find( F_qa == Fmin );
%else
 %  [~,id_shift]=min(abs(qa_lin-q0_shift));
%end

%plot(qa_lin, F_qa-F_qa(id_shift(1)),'color', cm(index,:), 'linewidth', 4);   hold on;
fsize=30; tsize=16;
xlabel(xname, 'fontsize', fsize); 
ylabel(yname, 'fontsize', fsize);
set(gca,'fontsize',fsize);
title(titlename, 'fontsize', fsize/2);
xlim([2 16])
saveas(gcf,[path,'/',prefix,'-',xname,'-',yname,'flip.png'])

