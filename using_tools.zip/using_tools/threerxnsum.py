import numpy as np
import matplotlib
import sys
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap
from matplotlib.lines import Line2D
from matplotlib.patches import Patch
def custom_cmap(cmap):
    """Return a grayscale version of the given colormap"""
    #print(cmap)
    cmap = plt.cm.get_cmap(cmap)
    colors = cmap(np.arange(cmap.N))
    #print(len(colors))
    colors = np.array(list(colors))
    # convert RGBA to perceived grayscale luminance
    # cf. http://alienryderflex.com/hsp.html
    #RGB_weight = [0.299, 0.587, 0.114]
    #luminance = np.sqrt(np.dot(colors[:, :3] ** 2, RGB_weight))
    #colors[:, :3] = luminance[:, np.newaxis]
    new_cmap = matplotlib.colors.ListedColormap(colors)
    new_cmap.set_over('black')
    new_cmap.set_under('white')
    bounds = [0.0, 1.0]
    norm = matplotlib.colors.BoundaryNorm(bounds, new_cmap.N)
    #return LinearSegmentedColormap.from_list(cmap.name + "_gray", colors, new_cmap.N)
    return new_cmap

def draw_line(minimally, highly,q,picturename):
    #crystal_q = q_data[0]
    others = q
    # cmap will generate a tuple of RGBA values for a given number in the range 0.0 to 1.0
    # (also 0 to 255 - not used in this example).
    # To map our z values cleanly to this range, we create a Normalize object.
    #new_cmap = matplotlib.cm.get_cmap('rainbow_r')  #https://matplotlib.org/examples/color/colormaps_reference.html
    new_cmap = custom_cmap('rainbow')
    #print(sorted(q_data, reverse=True)[1])
    #print(sorted(q_data, reverse=True))
    #q=q[len(q)-100:len(q)]
    #minimally=minimally[len(q)-100:len(q)]
    #highly=highly[len(q)-100:len(q)] 
    nummax = 25
    nummin = -25
    valuemax=sorted(others, reverse = True)[nummax]
    valuemin=sorted(others, reverse = True)[nummin]
    numt = len(others)
    #valuemax = 0.68
    #valuemin = 0.5
    #length = len(q)
    #minimally1=minimally[0:length-1]
    #highly1=highly[0:length-1]
    #q1=q[0:length-1]
    cmap = matplotlib.cm.get_cmap('rainbow')
    #rgba = cmap(0.5)
    normalize = matplotlib.colors.Normalize(vmin=0.139, vmax=0.879)
    #print min(others),sorted(others, reverse = True)[0]
    #normalize = matplotlib.colors.Normalize(vmin=0.0, vmax=1.0)
    colors = [new_cmap(normalize(value)) for value in others]
    plt.figure(figsize=(7.5,7.5))
    print q
    fig, ax = plt.subplots()
    plt.rcParams['font.family'] = 'serif'
    plt.rcParams['font.serif'] = ['Times New Roman'] + plt.rcParams['font.serif']
    #csfont = {'fontname':'Times'}
    #print len(q),len(minimally),len(highly)
    space = (len(q)-1)/4
    #print q
    for index in range(len(q)-1):
        #num = int(index/space + 1)/8.0
        #if num > 1:
        #   num = 1
        #plt.scatter(minimally[index], highly[index], marker='o',s = 30, color=cmap(num), edgecolors='black', linewidth=0.8)
        if minimally[index] < minimally[-1]:# and q[index] <= valuemax:
               plt.scatter(minimally[index], highly[index], marker='o',s = 40, color=colors[index], edgecolors='black', linewidth=0.8)
    plt.scatter(minimally[-1], highly[-1], marker='o',s = 60, color="k", edgecolors='black', linewidth=0.8)
    #plt.xlabel('# Minimally Frustrated Interactions', fontsize = 20)
    #plt.ylabel('# Highly Frustrated Interactions', fontsize = 20)
    #plt.xlim([np.min(minimally),np.max(minimally)])
    #plt.ylim([np.min(highly),np.max(highly)])
    cax, _ = matplotlib.colorbar.make_axes(ax)
    cbar = matplotlib.colorbar.ColorbarBase(cax, cmap=new_cmap, norm=normalize)
    #plt.xlabel('Fraction of minimally frustrated interactions', fontsize = 10)
    #plt.ylabel('Fraction of highly frustrated interactions', fontsize = 10)
    #plt.show()
    xticks = ax.xaxis.get_major_ticks()
    xticks[0].label1.set_visible(False)
    yticks = ax.yaxis.get_major_ticks()
    yticks[0].label1.set_visible(False)
    #for font in plt.rcParams['font.serif']:
    #    print fonit
    plt.show()
    plt.savefig('%s.png'%(picturename), bbox_inches='tight', dpi=600)
    #plt.show()
def main():
    #minifile = sys.argv[1]
    #highfile = sys.argv[2]
    #qfile = sys.argv[3]
    sumfile = sys.argv[1]
    sumt = np.loadtxt(sumfile)
    picturename = sys.argv[2]
    summ= sumt[sumt[:,2].argsort()]
    #print summ
    high=summ[:,0]
    mini=summ[:,1]
    q=summ[:,2]
    #mini = np.loadtxt(minifile)
    #high = np.loadtxt(highfile)
    #q = np.loadtxt(qfile)
    draw_line(mini, high,q,picturename)
if __name__ == '__main__':
    main()

