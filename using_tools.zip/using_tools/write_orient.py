import os
import numpy
import sys
datafile = sys.argv[1]
atom1 = int(sys.argv[2])
atom2 = int(sys.argv[3])
name = sys.argv[4]
Flag = "off"
with open(datafile,"r") as fopen:
     lines = fopen.readlines()
data ="colvar {\n    name    "+name +"\n    width   1\n    orientationAngle {\n        atoms {\n            atomNumbersRange "+ str(atom1) +"-" + str(atom2) + "\n        }\n        refPositions "
for line in lines:
    stdenv = line.split()
    if len(stdenv) > 0:
       if stdenv[0] == "Atoms":
          Flag = "halfon"
       if  Flag == "halfon" and len(stdenv) > 5:
           if int(stdenv[0]) == atom1:
              Flag = "on"
       if Flag == "on":
          data += "(" + stdenv[4] + ", " + stdenv[5] + ", " + stdenv[6] + ") "
       if  Flag == "on" and len(stdenv) > 5:
           if int(stdenv[0]) == atom2:
              Flag = "off"
data += "\n    }\n}\n\nharmonic {\n  name              "+name+"_pot\n  colvars           "+name+"\n  centers           0\n  forceConstant     20\n  outputEnergy      no\n}\n"
with open(name+".bias","w") as fwrite:
     fwrite.writelines(data)
