path = '/home/xc25/Data_dealing/51bp_left'
path = '/home/xc25/Data_dealing/PU_1_variable/angle_bias/angle_PDB'
path = '/home/xc25/Data_dealing/PU_1_variable/window_10_6/dist_P'
path = '/home/xc25/Data_dealing/ER_project/ER_3_old/bias/nocoa'
prefix = 'nocoa'
qa_name = 'distance'
T = 300
color_list = {'r','g','b','k'}
linestyle_list = {'-','--',':','-.'}
marker_list = {'o','*','s','d'}
flag = 1
fsize=20; tsize=16;
symbol_title = 'coa'
symbol_legend= 'coa'
index = 1
filename = sprintf("%s/%s_%d_pmf.dat",path,prefix,T)
FF = load(filename)
x = FF(:,1)
y = FF(:,2)
n_T=16;
cv=zeros(n_T,1); cm=colormap(jet(n_T))
%plot(x,y,'color', color_list{flag},'LineStyle',linestyle_list{flag},'Marker',marker_list{flag},'linewidth', 4); hold on;
%xlim([-25,-1])
plot(x,y,'color', cm(index,:),'linewidth', 4); hold on;
xlabel(qa_name, 'fontsize', fsize); ylabel('Free energy (kcal/mol)', 'fontsize', fsize)
title(symbol_title,'fontsize',fsize)
%lgd = legend(symbol_legend)
set(gca,'Xtick',0 : 20 : 100)
set(gca,'fontsize',fsize)
lgd.FontSize = fsize/4;
saveas(gcf,[path,'/',prefix,'-',qa_name,'.png'])