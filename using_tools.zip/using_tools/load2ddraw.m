 cm=colormap(jet(16))
curve_shift_flag=1; q0_shift=0.55;
cutoff=8.5;
n_contour=40
scrnsize = get(0,'ScreenSize'); 
fsize=25; tsize=16;
index = 1
prefix = 'round5' 
path = '/home/xun/victor/PU1_raw_data/D1/'
xname = 'Base pair index'
yname = 'E_{elec} PU.1-DNA'
refix = ''
%filename = sprintf('%s/qa%s-%s_combine.txt',path,xname,refix); qa_lin = load(filename);
%filename = sprintf('%s/qb%s-%s_combine.txt',path,yname,refix); qb_lin = load(filename);
%filename = sprintf('%s/H%s-%s_combine%s-%s_combine.txt',path,xname,refix,yname,refix); Fqa = load(filename);
filename = sprintf('%s/bsPD.txt',path); qa_lin = load(filename);
filename = sprintf('%s/ePD.txt',path); qb_lin = load(filename);
filename = sprintf('%s/bsePD.txt',path); Fqa = load(filename);
%Fqa=smooth(Fqa)
   %Fmin = min(Fqa); id_shift = find( Fqa == Fmin );
ids = (Fqa>= cutoff); Fqa(ids) = cutoff;
%plot(qa, Fqa-Fqa(id_shift(1)),'color', cm(index+4,:), 'linewidth', 4);   hold on;
 [~,h] = contourf(qa_lin, qb_lin,Fqa,n_contour);% shading flat,
 colormap(jet), col=colorbar, %set(col,'ylim',[0 10])name
 cm=colormap;
    %cm(64, :) = [1 1 1]
   % colormap(cm);
    ccc = get(h,'children'); max_cdata = -inf; cdata_list=zeros(size(ccc,1), 1);  
    for k=1:size(ccc,1)
        cd1 = get(ccc(k), 'cdata');
        if cd1 > max_cdata
            max_cdata = cd1 ;
        end
        cdata_list(k) = get(ccc(k),'cdata');
    end
    id = find(cdata_list == max_cdata);
    disp(ccc(id));
    for k=1:size(id,1)
        set(ccc(id(k)), 'facecolor', 'white');
    end 
%colormap(jet), col=colorbar, %set(col,'ylim',[0 10])name
%cm=colormap;
cm(16, :) = [1 1 1]
    %cm(63, :) = [1 1 1];
colormap(cm);
fsize=20; tsize=16;
xlabel([xname,' ',refix],'fontsize', fsize); ylabel([yname, ' ',refix], 'fontsize', fsize); %title([titlename], 'fontsize', fsize);set(gca,'fontsize',fsize)
set(gca,'fontsize',fsize/2)
%xlim([1,2])
%ylim([-0.6,0])
set(gca,'fontsize',fsize)
set(gca, 'FontName', 'Helvetica')
%saveas(gcf,[path,'./',xname,yname,refix,'.png'])
