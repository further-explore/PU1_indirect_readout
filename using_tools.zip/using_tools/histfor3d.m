PdbID = 'PaaA2'
Appd = '0.0'
filename1 = ['/home/xun/Downloads/data_sum/download-10/',PdbID,'/fragmem_on/',PdbID,'-',Appd,'/rg.txt']
filename2 = ['/home/xun/Downloads/data_sum/download-10/',PdbID,'/fragmem_on/',PdbID,'-',Appd,'/Dee.txt']
[data1,limit] = importdata(filename1);
[data2,limit] = importdata(filename2);
[P,Rg,Dee] = histcounts2(data1,data2,10000);
Rg = linspace(min(Rg), max(Rg), 10000)
Dee = linspace(min(Dee),max(Dee),10000)
P = P/10000
contour(Rg,Dee,P)