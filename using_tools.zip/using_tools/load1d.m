acm=colormap(jet(16))
curve_shift_flag=1; q0_shift=0.55;
cutoff=8.5;
n_contour=40
scrnsize = get(0,'ScreenSize'); 
fsize=25; tsize=16;
index = 1
prefix = 'round1' 
path = '/home/xun/victor/add1/T2_P2/elec/v1'
%path = '/home/xun/victor/PU1_raw_data/T2/'
%path = '/home/xun/victor/pureDNA2'
path='/home/xun/victor/add1/figure1'
path='/home/xun/victor/add1/pureDNAtest/design'
name = 'pdcharge1'
yname = 'Surface charge density'
%yname = 'Free energy (kcal/mol)'
filename = sprintf('%s/x-%s.txt',path,name); x = load(filename);
%x=2:2:98
filename = sprintf('%s/mean-%s.txt',path,name); mean1 =  load(filename)/1.54;
mean2=mean1
%for i=1:10
 %mean2(i)=mean1(length(mean1)-i)
%end
%for i=1:length(mean1)
    %if mean1
   % mean2(length(mean1)-i)=mean2(i)
%end
%for i in range
%means = mean2
%len2 = 47
%x1=zeros(len2,1)
%mean1=zeros(len2,1)
%for i=1:len2
%    x1(i)= (x(i*2-1)+x(i*2))/2
%    mean1(i)= (mean2(i*2-1)+mean2(i*2))/2 
%end
means = mean1
%filename = sprintf('%s/vars-%save.txt',path,name); vars = load(filename)/1.7;
%name = "Free energy(kcal/mol)"
%filename = sprintf('%s/qalin.txt',path); x = load(filename);
%filename = sprintf('%s/Fqa.txt',path); means = load(filename);
%filename = sprintf('%s/Fvar.txt',path); vars = load(filename);
%Fqa=smooth(Fqa)
meanmin=min(means)
%means=means-meanmin
%Fmin = min(Fqa); id_shift = find( Fqa == Fmin );
%ids = (Fqa>= cutoff); Fqa(ids) = cutoff;
%plot(qa, Fqa-Fqa(id_shift(1)),'color', cm(index+4,:), 'linewidth', 4);   hold on;
 %[~,h] = contourf(qa_lin, qb_lin,Fqa,n_contour);% shading flat,
 %colormap(jet), col=colorbar, %set(col,'ylim',[0 10])name
 %cm=colormap;
    %cm(64, :) = [1 1 1]
   % colormap(cm);
 %   ccc = get(h,'children'); max_cdata = -inf; cdata_list=zeros(size(ccc,1), 1);  
 %   for k=1:size(ccc,1)errorbar(x,means,vars,'-s','MarkerSize',10,'MarkerEdgeColor','red','MarkerFaceColor','red')
 %       cd1 = get(ccc(k), 'cdata');
 %       if cd1 > max_cdata
 %           max_cdata = cd1 ;
 %       end
 %       cdata_list(k) = get(ccc(k),'cdata');
 %   end
 %   id = find(cdata_list == max_cdata);
 %   disp(ccc(id));
 %   for k=1:size(id,1)
 %       set(ccc(id(k)), 'facecolor', 'white');
 %   end 

%vars=vars^3
%for i =1:49
%    vars(i) = vars(i)*vars(i)
%end

fsize=20; tsize=16;
plot(x,means,'-d','MarkerSize',10,'MarkerEdgeColor','red','MarkerFaceColor','red','linewidth',3)
xlabel('Base pair index', 'fontsize', fsize); ylabel(yname, 'fontsize', fsize); %title([titlename], 'fontsize', fsize);set(gca,'fontsize',fsize)
set(gca,'fontsize',fsize)
set(gca, 'FontName', 'Helvetica')
%saveas(gcf,[path,'/',name,'.png'])
xlim([1,100])
%ylim([0,20])
%ylim([min(means),max(means)])