import os
import sys
import numpy as np
from math import *
pfile = sys.argv[1]
edfile = sys.argv[2]
pmffile = sys.argv[3]
T=300

p=np.loadtxt(pfile)
ed=np.loadtxt(edfile)
pmf=np.loadtxt(pmffile)
[m,n] = np.shape(pmf)


spacenew = np.zeros(m+1)
spacenew[0] = np.min(p)
spacenew[m] = np.max(p)
prob = np.zeros(m)



for i in range(m-1):
    spacenew[i+1] = (pmf[i][0] + pmf[i+1][0])/2
    if pmf[i][1] <= -500 or pmf[i][1] > 500:
       prob[i] = 0
    else:
       prob[i] = exp(-pmf[i][1]/0.001987/T)
print prob
energypre = np.zeros(m)
probpre = np.zeros(m)
for i in range(len(p)):
    for j in range(m):
        if p[i] <= spacenew[j+1]:
           energypre[j] += prob[j] * ed[i]
           probpre[j] += prob[j]
print probpre
print energypre
for i in range(m):
    if prob[i] > 0:
       energypre[i] = energypre[i]/probpre[i]
    #else:
    #   energypre[i] = energypre[i]

#energynorm = np.max(energypre)
#print energynorm
print energypre
for i in range(m):
    if energypre[i] != 0 :
       pmf[i][1] = pmf[i][1] +  energypre[i] 
       #print energypre[i] - energynorm
    #else:
     #  pmf[i][1] = pmf[i][1] + 100000
np.savetxt("pmfadd.dat",pmf,fmt="%.3f",delimiter=" ")
